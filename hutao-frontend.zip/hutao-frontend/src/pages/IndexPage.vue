<template>
  <div class="index-page">
    <a-input-search
      v-model:value="searchText"
      placeholder="input search text"
      enter-button="Search"
      size="large"
      @search="onSearch"
    />
    <MyDivider />
    <a-tabs v-model:activeKey="activeKey" @change="onTabChange">
      <a-tab-pane key="post" tab="文章">
        <PostList :post-list="postList" />
      </a-tab-pane>
      <a-tab-pane key="picture" tab="图片">
        <PictureList :picture-list="pictureList" />
      </a-tab-pane>
      <a-tab-pane key="user" tab="用户">
        <UserList :user-list="userList" />
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script setup lang="ts">
import { ref, watchEffect } from "vue";
import PostList from "@/components/PostList";
import PictureList from "@/components/PictureList";
import UserList from "@/components/UserList";
import MyDivider from "@/components/MyDivider";
import { useRoute, useRouter } from "vue-router";
import myAxios from "@/plugins/myAxios";
import { message } from "ant-design-vue";

// 响应式变量定义，用于分别存储不同类型数据（帖子，用户，图片）
const postList = ref([]);
const userList = ref([]);
const pictureList = ref([]);

// 获取路由参数
// activeKey 用于获取当前选中的搜索类型
const route = useRoute();
const router = useRouter();
const activeKey = route.params.category;

// 用于初始化查询参数
const initSearchParams = {
  type: activeKey,
  text: "",
  pageSize: 10,
  pageNum: 1,
};

// 绑定路由参数中的文本到搜索词常量
const searchText = ref(route.params.text);

/**
 * 加载数据
 * @param params
 */
const loadDataOld = (params: any) => {
  // 封装 params 的 text 部分到 searchText 字段（接收 params 参数）
  // 构建帖子查询参数，封装原因：后端接口使用了 searchText 字段
  const postQuery = {
    ...params,
    searchText: params.text,
  };

  // 三个 post 请求，.value 用法说明属于 vue3 的响应式变量
  myAxios.post("/post/list/page/vo", postQuery).then((res: any) => {
    postList.value = res.records;
  });

  // 封装 params 的 text 部分到 userName 字段（接收 params 参数）
  // 构建帖子查询参数，封装原因：后端接口使用了 userName 字段
  const userQuery = {
    ...params,
    userName: params.text,
  };

  myAxios.post("/user/list/page/vo", userQuery).then((res: any) => {
    userList.value = res.records;
  });

  // 封装 params 的 text 部分到 searchText 字段（接收 params 参数）
  // 构建帖子查询参数，封装原因：后端接口使用了 searchText 字段
  const pictureQuery = {
    ...params,
    searchText: params.text,
  };

  myAxios.post("/picture/list/page/vo", pictureQuery).then((res: any) => {
    pictureList.value = res.records;
  });
};

/**
 * 加载聚合数据（新）
 * @param params
 */
const loadAllData = (params: any) => {
  // 使用统一接口，传入 searchText 作为 params，同时调用 user，post，picture 三个搜索接口
  // 仍然保留 searchText的 转换
  // 执行过程相当于将球放到新的盒子里（过滤）
  const query = {
    // 下面一行相当于把盒子拆开，把球展开
    ...params,
    // 把球放到 searchText 这个新的盒子里
    searchText: params.text,
  };
  // 三个 post 请求，.value 用法说明属于 vue3 的响应式变量
  myAxios.post("/search/all", query).then((res: any) => {
    postList.value = res.postList;
    userList.value = res.userList;
    pictureList.value = res.pictureList;
  });

  // 无需分别对不同 tab 定义不同的传入参数，即 userQuery 和 pictureQuery
  //
  // const userQuery = {
  //   ...params,
  //   userName: params.text,
  // };

  // myAxios.post("/user/list/page/vo", userQuery).then((res: any) => {
  //   userList.value = res.records;
  // });

  // const pictureQuery = {
  //   ...params,
  //   searchText: params.text,
  // };

  // myAxios.post("/picture/list/page/vo", pictureQuery).then((res: any) => {
  //   pictureList.value = res.records;
  // });
};

/**
 * 加载单类数据
 * @param params
 */
const loadData = (params: any) => {
  const { type } = params;
  if (!type) {
    message.error("类别为空");
    return;
  }
  // 使用统一接口，传入 searchText 作为 params，同时调用 user，post，picture 三个搜索接口
  // 仍然保留 searchText的 转换
  // 执行过程相当于将球放到新的盒子里（过滤）
  const query = {
    // 下面一行相当于把盒子拆开，把球展开
    ...params,
    // 把球放到 searchText 这个新的盒子里
    searchText: params.text,
  };
  // 三个 post 请求，.value 用法说明属于 vue3 的响应式变量
  myAxios.post("/search/all", query).then((res: any) => {
    // alert("type: " + type);
    if (type === "post") {
      postList.value = res.dataList;
    } else if (type === "user") {
      userList.value = res.dataList;
    } else if (type === "picture") {
      pictureList.value = res.dataList;
    }
  });
};

const searchParams = ref(initSearchParams);

// 监听器，自动跟踪 text 响应式数据，根据 text 变化重新执行函数
// 在路由参数改变时，自动更新查询参数，并重新拉取相应类型的数据，简化查询参数和路由之间的同步。
// 每次，更新 searchParams.value 为新的搜索参数对象，保留 initSearchParams 中的默认值，并把 route.query.text 添加进去
// 实现搜索状态同步
watchEffect(() => {
  searchParams.value = {
    ...initSearchParams,
    text: route.query.text,
    type: route.params.category,
  } as any;
  loadData(searchParams.value);
});

// 搜索触发函数
// router.push() 更改当前页面 url 的查询参数并触发 watchEffect
// 同时调用 loadData 重新加载数据
const onSearch = (value: string) => {
  console.log(value);
  router.push({
    query: {
      ...searchParams.value,
      text: value,
    },
  });
  // loadData(searchParams.value);
};

// 标签切换逻辑
// 切换 tab 时会跳转到新的路由，同时保留当前搜索参数，仍然挂在 query 上
const onTabChange = (key: string) => {
  router.push({
    path: `/${key}`,
    query: searchParams.value,
  });
};
</script>
