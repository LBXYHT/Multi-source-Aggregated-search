package com.hutao.aggregatedsearch.model.entity;

import lombok.Data;

/**
 * 图片
 */
@Data
public class Picture {

    private String title;

    private String url;
}
