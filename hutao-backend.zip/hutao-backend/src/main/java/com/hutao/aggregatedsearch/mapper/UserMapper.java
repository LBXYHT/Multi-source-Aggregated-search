package com.hutao.aggregatedsearch.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hutao.aggregatedsearch.model.entity.User;

/**
 * 用户数据库操作
 *
 */
public interface UserMapper extends BaseMapper<User> {

}




